from django.contrib import admin
from .models import MotherProfile, ServiceBooking

admin.site.register(MotherProfile)
admin.site.register(ServiceBooking)