from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login
from django.contrib import messages


def home(request):
    return render(request, "home.html")


def register(request):
    if request.method == "POST":
        name = request.POST.get("name", "").strip()
        email = request.POST.get("email", "").strip().lower()
        phone = request.POST.get("phone", "").strip()
        password = request.POST.get("password", "")

        if not name or not email or not password:
            messages.error(request, "Please fill in all required fields.")
            return redirect("register")

        if User.objects.filter(email=email).exists():
            messages.error(request, "An account with this email already exists.")
            return redirect("register")

        user = User.objects.create_user(
            username=email,
            email=email,
            password=password,
            first_name=name
        )

        user.save()

        messages.success(
            request,
            "Account created successfully. Please log in."
        )

        return redirect("login")

    return render(request, "home.html")


def login_user(request):
    if request.method == "POST":
        email = request.POST.get("email", "").strip().lower()
        password = request.POST.get("password", "")

        user = authenticate(
            request,
            username=email,
            password=password
        )

        if user is not None:
            login(request, user)

            messages.success(
                request,
                "Welcome back to MotherCare!"
            )

            return redirect("home")

        messages.error(
            request,
            "Invalid email or password."
        )

        return redirect("login")

    return render(request, "home.html")
