from django.db import models


class MotherProfile(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField(unique=True)
    phone = models.CharField(max_length=15)
    password = models.CharField(max_length=128)
    package = models.CharField(max_length=100, blank=True)
    address = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name


class ServiceBooking(models.Model):
    SERVICE_CHOICES = [
        ("Cooking Service", "Cooking Service"),
        ("Home Cleaning", "Home Cleaning"),
        ("Laundry Service", "Laundry Service"),
        ("Grocery Delivery", "Grocery Delivery"),
        ("Nurse Home Visit", "Nurse Home Visit"),
        ("Doctor Consultation", "Doctor Consultation"),
    ]

    mother = models.ForeignKey(
        MotherProfile,
        on_delete=models.CASCADE
    )

    service = models.CharField(
        max_length=100,
        choices=SERVICE_CHOICES
    )

    booking_date = models.DateField()
    booking_time = models.CharField(max_length=50)
    address = models.TextField()
    note = models.TextField(blank=True)
    status = models.CharField(
        max_length=30,
        default="Pending"
    )

    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.mother.name} - {self.service}"