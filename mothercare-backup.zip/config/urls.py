from django.contrib import admin
from django.urls import path
from care.views import home, register, login_user


urlpatterns = [
    path("admin/", admin.site.urls),
    path("", home, name="home"),
    path("register/", register, name="register"),
    path("login/", login_user, name="login"),
]